DATABASES = {
    'default':{
    'ENGINE':'django.db.backends.mysql',
    'NAME':'TEST', #db이름
    'USER':'root',
    'PASSWORD':'1234',
    'HOST':'127.0.0.1',
    'PORT':'3305',
    }
}
SECRET_KEY = 'django-insecure-1zyo#nw&o4$mto#%67=kh!l20slg@=nz@ft500v-*oalra*=im'