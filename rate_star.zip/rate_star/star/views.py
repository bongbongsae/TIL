from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse
from .models import *
import random
import pymysql

# Create your views here.
def index(request) :
    return render(request, 'star/index.html')

def to_db(user_input_star):
    star_rate = pymysql.connect(
        user='root',
        passwd='1234',
        host='127.0.0.1',
        db='test',
        charset='utf8',
        port = 3305
    )
    cursor = star_rate.cursor(pymysql.cursors.DictCursor)
    insert_data=[{'id': 11,'rate': user_input_star}]
    insert_sql = "INSERT INTO `star_rate` VALUES (%(id)s,%(rate)s);"
    cursor.executemany(insert_sql, insert_data)
    star_rate.commit()

def savestar(request) :

    user_input_star = int(request.GET['checked'])
    to_db(user_input_star)
    print('완료한 별점', user_input_star)
    return HttpResponse(user_input_star)
    # return redirect(reverse('index'))






# def savestar(request) :
#     # 파이썬 3.9이상
#     # ** value1 = int(request.GET['num1'])
#     # value2 = int(request.GET['num2']) **
#     # user_input_star = request.POST.get['idx']
#     # is_private = request.POST.get('is_private', False)
#     user_input_star = int(request.POST.get('checked', False))
#     # user_input_star = int(request.GET['checked'])
#     stars = StarRate.objects.save()
#     id = StarRate(content = random.randint(1, 10000))
#     id.save()
#     rate = StarRate(content = user_input_star)
#     rate.save()
#     print('완료한 별점', stars)
#
#     return HttpResponse('별점 test =>' +stars)
#     # return redirect(reverse('index'))