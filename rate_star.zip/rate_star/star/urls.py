
from django.urls import path
from . import views
import star.views


urlpatterns = [
    path('', views.index),
    path('savestar/', star.views.savestar, name = 'savestar'),
]